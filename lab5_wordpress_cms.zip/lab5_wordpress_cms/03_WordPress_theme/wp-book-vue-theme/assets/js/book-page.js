(function(){
  const root = document.getElementById('booklab-book-app');
  if (!root || !window.Vue) return;
  const api = root.dataset.restUrl;
  const nonce = root.dataset.nonce;
  const bookId = root.dataset.bookId;

  function apiUrl(path) {
    return api.replace(/\/$/, '') + path;
  }

  const BookDetailPage = {
    template: `
      <section class="booklab-card">
        <div v-if="error" class="booklab-error">
          {{ error }} <a :href="loginUrl">Войти</a>
        </div>
        <div v-else-if="book">
          <h1>{{ book.title }}</h1>
          <img class="booklab-cover" :src="book.cover_url" :alt="book.title">
          <p><strong>Автор:</strong> {{ book.author || 'Не указан' }}</p>
          <p><strong>Описание:</strong> {{ book.description || 'Нет описания' }}</p>
          <p><strong>Цена:</strong> {{ book.price }}</p>
          <p><a class="booklab-btn" :href="book.download_url" download>Скачать книгу</a></p>
          <p v-if="book.product_url"><a class="booklab-btn secondary" :href="book.product_url">Купить через WooCommerce</a></p>
          <h3>Обложки</h3>
          <div class="booklab-grid"><img v-for="c in book.covers" :key="c.id" class="booklab-cover" :src="c.url"></div>
        </div>
        <p v-else>Загрузка...</p>
      </section>`,
    setup(){
      const book = Vue.ref(null), error = Vue.ref('');
      const loginUrl = '/wp-login.php';
      fetch(apiUrl('/books/' + bookId), {headers:{'X-WP-Nonce': nonce}}).then(async r => {
        const data = await r.json();
        if (!r.ok) { error.value = data.message || 'Доступ к детальной информации разрешен только после авторизации.'; return; }
        book.value = data;
      });
      return {book, error, loginUrl};
    }
  };
  Vue.createApp({components:{BookDetailPage}}).mount(root);
})();
