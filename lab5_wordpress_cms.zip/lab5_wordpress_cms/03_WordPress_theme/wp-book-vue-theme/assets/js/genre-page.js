(function(){
  const root = document.getElementById('booklab-genre-app');
  if (!root || !window.Vue) return;
  const api = root.dataset.restUrl;
  const genreId = root.dataset.genreId;

  function apiUrl(path) {
    return api.replace(/\/$/, '') + path;
  }

  const GenreBooksPage = {
    template: `
      <section class="booklab-card">
        <h1>{{ genre.name || 'Жанр' }}</h1>
        <p>{{ genre.description }}</p>
        <div class="booklab-grid">
          <article v-for="b in books" :key="b.id" class="booklab-card">
            <img class="booklab-cover" :src="b.cover_url" :alt="b.title">
            <h3>{{ b.title }}</h3>
            <p>{{ b.author }}</p>
            <p>{{ b.description }}</p>
            <a class="booklab-btn" :href="b.url">Открыть книгу</a>
          </article>
        </div>
        <p v-if="books.length === 0" class="booklab-muted">В этом жанре пока нет книг.</p>
      </section>`,
    setup(){
      const genre = Vue.ref({}), books = Vue.ref([]);
      fetch(apiUrl('/genres/' + genreId + '/books')).then(r=>r.json()).then(data => { genre.value = data.genre || {}; books.value = data.books || []; });
      return {genre, books};
    }
  };
  Vue.createApp({components:{GenreBooksPage}}).mount(root);
})();
