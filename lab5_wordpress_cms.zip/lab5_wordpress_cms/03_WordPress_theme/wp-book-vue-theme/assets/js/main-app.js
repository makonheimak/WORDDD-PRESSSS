(function(){
  const root = document.getElementById('booklab-main-app');
  if (!root || !window.Vue) return;
  const api = root.dataset.restUrl;
  const nonce = root.dataset.nonce;
  const logged = root.dataset.logged === '1';
  const bus = Vue.reactive({ currentBook: null, genres: [] });
  const headers = { 'X-WP-Nonce': nonce };

  function apiUrl(path, params = {}) {
    const separator = api.includes('?') ? '&' : '?';
    let url = api.replace(/\/$/, '') + path;
    const query = new URLSearchParams(params).toString();
    return query ? url + separator + query : url;
  }

  const BookUpload = {
    template: `
      <section class="booklab-card">
        <h2>1. Загрузка текстовой книги</h2>
        <p class="booklab-muted">Допускаются только .txt файлы до 5 МБ. Доступно перетаскивание и классический выбор файла.</p>
        <div v-if="!logged" class="booklab-error">Загрузка доступна только авторизованным пользователям.</div>
        <div v-else>
          <div class="booklab-drop" :class="{active: drag}" @dragover.prevent="drag=true" @dragleave.prevent="drag=false" @drop.prevent="drop">
            <p>Перетащите .txt файл сюда</p>
            <input type="file" accept=".txt,text/plain" @change="select">
          </div>
          <p v-if="error" class="booklab-error">{{ error }}</p>
          <p v-if="message" class="booklab-success">{{ message }}</p>
          <div v-if="bus.currentBook" class="booklab-card">
            <h3>Данные книги</h3>
            <label>Название</label><input class="booklab-input" v-model="form.title">
            <label>Автор</label><input class="booklab-input" v-model="form.author">
            <label>Жанр</label><select class="booklab-select" v-model="form.genre_id"><option value="">Не выбран</option><option v-for="g in bus.genres" :value="g.id">{{ g.name }}</option></select>
            <label>Цена для WooCommerce</label><input class="booklab-input" type="number" min="0" step="0.01" v-model="form.price">
            <label>Краткое описание</label><textarea class="booklab-textarea" rows="4" v-model="form.description"></textarea>
            <button class="booklab-btn" @click="saveMeta">Сохранить данные книги</button>
          </div>
        </div>
      </section>`,
    setup(){
      const drag = Vue.ref(false), error = Vue.ref(''), message = Vue.ref('');
      const form = Vue.reactive({title:'', author:'', genre_id:'', description:'', price:0});
      function validate(file){
        if (!file) return 'Файл не выбран.';
        if (file.size > 5 * 1024 * 1024) return 'Файл больше 5 МБ.';
        if (!file.name.toLowerCase().endsWith('.txt') && file.type !== 'text/plain') return 'Нужен текстовый файл .txt.';
        return '';
      }
      async function upload(file){
        error.value=''; message.value='';
        const v = validate(file); if (v) { error.value = v; return; }
        const fd = new FormData(); fd.append('book_file', file); fd.append('title', file.name.replace(/\.txt$/i,''));
        const res = await fetch(apiUrl('/books/upload'), {method:'POST', headers, body:fd});
        const data = await res.json();
        if (!res.ok) { error.value = data.message || 'Ошибка загрузки.'; return; }
        bus.currentBook = data; Object.assign(form, {title:data.title, author:'', genre_id:'', description:'', price:0});
        message.value = 'Книга загружена. Заполните жанр, автора и описание.';
      }
      function select(e){ upload(e.target.files[0]); }
      function drop(e){ drag.value=false; upload(e.dataTransfer.files[0]); }
      async function saveMeta(){
        if (!bus.currentBook) return;
        const res = await fetch(apiUrl('/books/' + bus.currentBook.id), {method:'POST', headers: {'Content-Type':'application/json', ...headers}, body:JSON.stringify(form)});
        const data = await res.json();
        if (!res.ok) { error.value = data.message || 'Ошибка сохранения.'; return; }
        bus.currentBook = data; message.value = 'Данные книги сохранены.';
      }
      return {logged, bus, drag, error, message, form, select, drop, saveMeta};
    }
  };

  const CoverUpload = {
    template: `
      <section class="booklab-card">
        <h2>2. Загрузка обложек книги</h2>
        <p class="booklab-muted">Компонент появляется после успешной загрузки текстового документа. Количество обложек не ограничено, размер каждой до 5 МБ.</p>
        <div v-if="!bus.currentBook" class="booklab-muted">Сначала загрузите книгу.</div>
        <div v-else>
          <input type="file" accept="image/*" @change="select">
          <p v-if="error" class="booklab-error">{{ error }}</p>
          <p v-if="message" class="booklab-success">{{ message }}</p>
        </div>
      </section>`,
    setup(){
      const error = Vue.ref(''), message = Vue.ref('');
      async function select(e){
        const file = e.target.files[0]; error.value=''; message.value='';
        if (!file) return;
        if (file.size > 5 * 1024 * 1024) { error.value = 'Обложка больше 5 МБ.'; return; }
        const fd = new FormData(); fd.append('cover_file', file);
        const res = await fetch(apiUrl('/books/' + bus.currentBook.id + '/covers'), {method:'POST', headers, body:fd});
        const data = await res.json();
        if (!res.ok) { error.value = data.message || 'Ошибка загрузки обложки.'; return; }
        message.value = 'Обложка добавлена.';
      }
      return {bus, error, message, select};
    }
  };

  const GenreList = {
    template: `
      <section class="booklab-card">
        <h2>3. Жанры с добавленными книгами</h2>
        <div class="booklab-grid">
          <article v-for="g in genres" :key="g.id" class="booklab-card">
            <img class="booklab-cover" :src="g.cover_url" :alt="g.name">
            <h3>{{ g.name }}</h3>
            <p>{{ g.book_count }} книг</p>
            <button class="booklab-btn secondary" @click="open(g.url)">Смотреть книги</button>
          </article>
        </div>
        <p v-if="genres.length === 0" class="booklab-muted">Пока нет жанров с книгами.</p>
      </section>`,
    setup(){
      const genres = Vue.ref([]);
      async function load(){
        const res = await fetch(apiUrl('/genres', {only_with_books: 1}));
        genres.value = await res.json();
        bus.genres = genres.value.length ? genres.value : await (await fetch(apiUrl('/genres'))).json();
      }
      function open(url){ window.location.href = url; }
      load();
      return {genres, open};
    }
  };

  fetch(apiUrl('/genres')).then(r=>r.json()).then(data=>{ bus.genres = data; });
  Vue.createApp({components:{BookUpload, CoverUpload, GenreList}}).mount(root);
})();
