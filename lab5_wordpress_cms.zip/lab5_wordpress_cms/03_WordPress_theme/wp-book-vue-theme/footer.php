<footer class="booklab-footer">
  <div class="booklab-container">Лабораторная работа №5. WordPress, Vue.js, REST API, MySQL.</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
