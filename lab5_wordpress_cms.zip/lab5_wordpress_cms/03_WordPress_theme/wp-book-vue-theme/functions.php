<?php
if (!defined('ABSPATH')) { exit; }

define('BOOKLAB_THEME_PATH', get_template_directory());
define('BOOKLAB_THEME_URL', get_template_directory_uri());
define('BOOKLAB_MAX_FILE_SIZE', 5 * 1024 * 1024);

require_once BOOKLAB_THEME_PATH . '/includes/schema.php';
require_once BOOKLAB_THEME_PATH . '/includes/helpers.php';
require_once BOOKLAB_THEME_PATH . '/includes/rest-api.php';
require_once BOOKLAB_THEME_PATH . '/includes/frontend.php';

add_action('after_switch_theme', 'booklab_theme_activate');
function booklab_theme_activate() {
    booklab_create_tables();
    booklab_seed_genres();
    booklab_add_rewrite_rules();
    flush_rewrite_rules();
}

add_action('switch_theme', 'booklab_theme_deactivate');
function booklab_theme_deactivate() {
    booklab_drop_tables();
    flush_rewrite_rules();
}

add_action('init', 'booklab_add_rewrite_rules');
function booklab_add_rewrite_rules() {
    add_rewrite_rule('^genre/([0-9]+)/?$', 'index.php?booklab_page=genre&booklab_genre_id=$matches[1]', 'top');
    add_rewrite_rule('^book/([0-9]+)/?$', 'index.php?booklab_page=book&booklab_book_id=$matches[1]', 'top');
}

add_filter('query_vars', function($vars) {
    $vars[] = 'booklab_page';
    $vars[] = 'booklab_genre_id';
    $vars[] = 'booklab_book_id';
    return $vars;
});

add_filter('template_include', function($template) {
    $page = get_query_var('booklab_page');
    if ($page === 'genre') {
        return BOOKLAB_THEME_PATH . '/templates/genre-page.php';
    }
    if ($page === 'book') {
        return BOOKLAB_THEME_PATH . '/templates/book-page.php';
    }
    return $template;
});
