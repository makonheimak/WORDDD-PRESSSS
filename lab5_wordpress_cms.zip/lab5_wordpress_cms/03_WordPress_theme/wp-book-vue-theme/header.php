<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="booklab-header">
  <div class="booklab-container">
    <a href="<?php echo esc_url(home_url('/')); ?>"><strong>BookLab CMS</strong></a>
    <?php if (is_user_logged_in()) : ?>
      <a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>">Выйти</a>
    <?php else : ?>
      <a href="<?php echo esc_url(wp_login_url()); ?>">Войти</a>
      <a href="<?php echo esc_url(wp_registration_url()); ?>">Регистрация</a>
    <?php endif; ?>
  </div>
</header>
