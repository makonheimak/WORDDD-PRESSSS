<?php
if (!defined('ABSPATH')) { exit; }

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('booklab-style', get_stylesheet_uri(), [], '1.0.0');
    wp_enqueue_script('vue3', 'https://unpkg.com/vue@3/dist/vue.global.prod.js', [], '3.4.0', true);

    if (is_front_page() || is_home()) {
        wp_enqueue_script('booklab-main', BOOKLAB_THEME_URL . '/assets/js/main-app.js', ['vue3'], '1.0.0', true);
    }
    if (get_query_var('booklab_page') === 'genre') {
        wp_enqueue_script('booklab-genre', BOOKLAB_THEME_URL . '/assets/js/genre-page.js', ['vue3'], '1.0.0', true);
    }
    if (get_query_var('booklab_page') === 'book') {
        wp_enqueue_script('booklab-book', BOOKLAB_THEME_URL . '/assets/js/book-page.js', ['vue3'], '1.0.0', true);
    }
});
