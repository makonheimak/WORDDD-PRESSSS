<?php
if (!defined('ABSPATH')) { exit; }

function booklab_upload_dir($type) {
    $upload = wp_upload_dir();
    $subdir = $type === 'cover' ? 'booklab/covers' : 'booklab/books';
    $dir = trailingslashit($upload['basedir']) . $subdir;
    $url = trailingslashit($upload['baseurl']) . $subdir;
    if (!file_exists($dir)) {
        wp_mkdir_p($dir);
    }
    return ['dir' => $dir, 'url' => $url];
}

function booklab_validate_uploaded_file($file, $allowed_mimes) {
    if (empty($file) || !isset($file['tmp_name'])) {
        return new WP_Error('no_file', 'Файл не передан.', ['status' => 400]);
    }
    if (!empty($file['error'])) {
        return new WP_Error('upload_error', 'Ошибка загрузки файла.', ['status' => 400]);
    }
    if ((int)$file['size'] > BOOKLAB_MAX_FILE_SIZE) {
        return new WP_Error('file_too_large', 'Размер файла превышает 5 МБ.', ['status' => 413]);
    }
    $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name']);
    $mime = $check['type'] ?: $file['type'];
    if (!in_array($mime, $allowed_mimes, true)) {
        return new WP_Error('invalid_type', 'Недопустимый формат файла.', ['status' => 415]);
    }
    return true;
}

function booklab_save_uploaded_file($file, $type) {
    $target = booklab_upload_dir($type);
    $safe_name = wp_unique_filename($target['dir'], sanitize_file_name($file['name']));
    $path = trailingslashit($target['dir']) . $safe_name;
    if (!move_uploaded_file($file['tmp_name'], $path)) {
        return new WP_Error('move_failed', 'Не удалось сохранить файл.', ['status' => 500]);
    }
    return [
        'path' => $path,
        'url' => trailingslashit($target['url']) . $safe_name,
        'name' => $safe_name,
    ];
}

function booklab_book_public_url($book_id) {
    return home_url('/book/' . absint($book_id) . '/');
}

function booklab_genre_public_url($genre_id) {
    return home_url('/genre/' . absint($genre_id) . '/');
}

function booklab_prepare_book($row, $detailed = false) {
    global $wpdb;
    if (!$row) { return null; }
    $covers = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . booklab_table('covers') . ' WHERE book_id = %d ORDER BY is_main DESC, id DESC', $row->id));
    $main_cover = $covers ? $covers[0]->cover_url : BOOKLAB_THEME_URL . '/assets/img/default-book.svg';
    $data = [
        'id' => (int)$row->id,
        'genre_id' => (int)$row->genre_id,
        'title' => $row->title,
        'author' => $row->author,
        'description' => $detailed ? $row->description : wp_trim_words((string)$row->description, 24),
        'cover_url' => $main_cover,
        'url' => booklab_book_public_url($row->id),
        'price' => (float)$row->price,
        'created_at' => $row->created_at,
    ];
    if ($detailed) {
        $data['download_url'] = $row->file_url;
        $data['covers'] = array_map(function($cover) {
            return ['id' => (int)$cover->id, 'url' => $cover->cover_url, 'is_main' => (bool)$cover->is_main];
        }, $covers);
        if (!empty($row->wc_product_id) && function_exists('wc_get_product')) {
            $product = wc_get_product((int)$row->wc_product_id);
            if ($product) {
                $data['product_url'] = get_permalink($product->get_id());
                $data['product_id'] = $product->get_id();
            }
        }
    }
    return $data;
}
