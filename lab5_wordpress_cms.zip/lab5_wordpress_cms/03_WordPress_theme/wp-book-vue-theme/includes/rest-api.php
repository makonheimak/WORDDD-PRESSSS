<?php
if (!defined('ABSPATH')) { exit; }

add_action('rest_api_init', function() {
    register_rest_route('booklab/v1', '/genres', [
        'methods' => WP_REST_Server::READABLE,
        'callback' => 'booklab_rest_genres',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('booklab/v1', '/genres/(?P<id>\d+)/books', [
        'methods' => WP_REST_Server::READABLE,
        'callback' => 'booklab_rest_books_by_genre',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('booklab/v1', '/books/(?P<id>\d+)', [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => 'booklab_rest_book_detail',
            'permission_callback' => 'is_user_logged_in',
        ],
        [
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => 'booklab_rest_update_book',
            'permission_callback' => 'is_user_logged_in',
        ],
    ]);

    register_rest_route('booklab/v1', '/books/upload', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'booklab_rest_upload_book',
        'permission_callback' => 'is_user_logged_in',
    ]);

    register_rest_route('booklab/v1', '/books/(?P<id>\d+)/covers', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'booklab_rest_upload_cover',
        'permission_callback' => 'is_user_logged_in',
    ]);
});

function booklab_rest_genres(WP_REST_Request $request) {
    global $wpdb;
    $genres = booklab_table('genres');
    $books = booklab_table('books');
    $only = (bool)$request->get_param('only_with_books');
    if ($only) {
        $rows = $wpdb->get_results("SELECT g.*, COUNT(b.id) AS book_count FROM $genres g INNER JOIN $books b ON b.genre_id = g.id GROUP BY g.id ORDER BY g.name ASC");
    } else {
        $rows = $wpdb->get_results("SELECT g.*, (SELECT COUNT(*) FROM $books b WHERE b.genre_id = g.id) AS book_count FROM $genres g ORDER BY g.name ASC");
    }
    return array_map(function($row) {
        return [
            'id' => (int)$row->id,
            'name' => $row->name,
            'description' => $row->description,
            'cover_url' => $row->cover_url,
            'book_count' => (int)$row->book_count,
            'url' => booklab_genre_public_url($row->id),
        ];
    }, $rows);
}

function booklab_rest_books_by_genre(WP_REST_Request $request) {
    global $wpdb;
    $id = absint($request['id']);
    $genre = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . booklab_table('genres') . ' WHERE id = %d', $id));
    if (!$genre) {
        return new WP_Error('not_found', 'Жанр не найден.', ['status' => 404]);
    }
    $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . booklab_table('books') . ' WHERE genre_id = %d ORDER BY created_at DESC', $id));
    return [
        'genre' => ['id' => (int)$genre->id, 'name' => $genre->name, 'description' => $genre->description],
        'books' => array_map(function($row) { return booklab_prepare_book($row, false); }, $rows),
    ];
}

function booklab_rest_book_detail(WP_REST_Request $request) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . booklab_table('books') . ' WHERE id = %d', absint($request['id'])));
    if (!$row) {
        return new WP_Error('not_found', 'Книга не найдена.', ['status' => 404]);
    }
    return booklab_prepare_book($row, true);
}

function booklab_rest_upload_book(WP_REST_Request $request) {
    global $wpdb;
    $files = $request->get_file_params();
    $file = $files['book_file'] ?? null;
    $valid = booklab_validate_uploaded_file($file, ['text/plain']);
    if (is_wp_error($valid)) { return $valid; }
    $saved = booklab_save_uploaded_file($file, 'book');
    if (is_wp_error($saved)) { return $saved; }

    $title = sanitize_text_field($request->get_param('title')) ?: preg_replace('/\.txt$/i', '', $file['name']);
    $wpdb->insert(booklab_table('books'), [
        'genre_id' => null,
        'title' => $title,
        'author' => '',
        'description' => '',
        'file_url' => esc_url_raw($saved['url']),
        'file_path' => $saved['path'],
        'file_name' => $saved['name'],
        'file_size' => absint($file['size']),
        'mime_type' => 'text/plain',
        'price' => 0,
    ]);
    $id = (int)$wpdb->insert_id;
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . booklab_table('books') . ' WHERE id = %d', $id));
    return new WP_REST_Response(booklab_prepare_book($row, true), 201);
}

function booklab_rest_update_book(WP_REST_Request $request) {
    global $wpdb;
    $id = absint($request['id']);
    $exists = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . booklab_table('books') . ' WHERE id = %d', $id));
    if (!$exists) { return new WP_Error('not_found', 'Книга не найдена.', ['status' => 404]); }
    $genre_id = $request->get_param('genre_id') ? absint($request->get_param('genre_id')) : null;
    $wpdb->update(booklab_table('books'), [
        'genre_id' => $genre_id,
        'title' => sanitize_text_field($request->get_param('title')),
        'author' => sanitize_text_field($request->get_param('author')),
        'description' => wp_kses_post($request->get_param('description')),
        'price' => (float)$request->get_param('price'),
        'updated_at' => current_time('mysql'),
    ], ['id' => $id]);
    $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . booklab_table('books') . ' WHERE id = %d', $id));
    return booklab_prepare_book($row, true);
}

function booklab_rest_upload_cover(WP_REST_Request $request) {
    global $wpdb;
    $book_id = absint($request['id']);
    $book = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . booklab_table('books') . ' WHERE id = %d', $book_id));
    if (!$book) { return new WP_Error('not_found', 'Книга не найдена.', ['status' => 404]); }
    $files = $request->get_file_params();
    $file = $files['cover_file'] ?? null;
    $valid = booklab_validate_uploaded_file($file, ['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
    if (is_wp_error($valid)) { return $valid; }
    $saved = booklab_save_uploaded_file($file, 'cover');
    if (is_wp_error($saved)) { return $saved; }
    $count = (int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . booklab_table('covers') . ' WHERE book_id = %d', $book_id));
    $wpdb->insert(booklab_table('covers'), [
        'book_id' => $book_id,
        'cover_url' => esc_url_raw($saved['url']),
        'cover_path' => $saved['path'],
        'is_main' => $count === 0 ? 1 : 0,
    ]);
    return new WP_REST_Response(['message' => 'Обложка добавлена.', 'cover_url' => $saved['url']], 201);
}
