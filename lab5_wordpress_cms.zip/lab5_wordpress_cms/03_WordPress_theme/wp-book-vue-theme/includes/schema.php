<?php
if (!defined('ABSPATH')) { exit; }

function booklab_table($name) {
    global $wpdb;
    return $wpdb->prefix . 'booklab_' . $name;
}

function booklab_create_tables() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset_collate = $wpdb->get_charset_collate();

    $genres = booklab_table('genres');
    $books = booklab_table('books');
    $covers = booklab_table('covers');

    $sql_genres = "CREATE TABLE $genres (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(120) NOT NULL,
        slug VARCHAR(160) NOT NULL,
        description TEXT NULL,
        cover_url VARCHAR(500) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY slug (slug)
    ) $charset_collate;";

    $sql_books = "CREATE TABLE $books (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        genre_id BIGINT UNSIGNED NULL,
        title VARCHAR(255) NOT NULL,
        author VARCHAR(255) NULL,
        description TEXT NULL,
        file_url VARCHAR(500) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_size BIGINT UNSIGNED NOT NULL,
        mime_type VARCHAR(120) NOT NULL,
        price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        wc_product_id BIGINT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NULL,
        PRIMARY KEY  (id),
        KEY genre_id (genre_id),
        KEY created_at (created_at)
    ) $charset_collate;";

    $sql_covers = "CREATE TABLE $covers (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        book_id BIGINT UNSIGNED NOT NULL,
        cover_url VARCHAR(500) NOT NULL,
        cover_path VARCHAR(500) NOT NULL,
        is_main TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY book_id (book_id)
    ) $charset_collate;";

    dbDelta($sql_genres);
    dbDelta($sql_books);
    dbDelta($sql_covers);
}

function booklab_drop_tables() {
    global $wpdb;
    $wpdb->query('DROP TABLE IF EXISTS ' . booklab_table('covers'));
    $wpdb->query('DROP TABLE IF EXISTS ' . booklab_table('books'));
    $wpdb->query('DROP TABLE IF EXISTS ' . booklab_table('genres'));
}

function booklab_seed_genres() {
    global $wpdb;
    $genres = booklab_table('genres');
    $items = [
        ['Фантастика', 'fantastika', 'Книги о будущем, космосе, технологиях и альтернативных мирах.'],
        ['Детектив', 'detektiv', 'Произведения с расследованиями, тайнами и преступлениями.'],
        ['Роман', 'roman', 'Художественная проза о жизни, отношениях и судьбах героев.'],
        ['Научная литература', 'nauchnaya-literatura', 'Познавательные и научно-популярные книги.'],
        ['История', 'istoriya', 'Книги об исторических событиях, эпохах и личностях.'],
        ['Программирование', 'programmirovanie', 'Технические книги по разработке и IT.'],
    ];
    foreach ($items as $item) {
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $genres WHERE slug = %s", $item[1]));
        if (!$exists) {
            $wpdb->insert($genres, [
                'name' => $item[0],
                'slug' => $item[1],
                'description' => $item[2],
                'cover_url' => BOOKLAB_THEME_URL . '/assets/img/default-genre.svg',
            ]);
        }
    }
}
