<?php get_header(); ?>
<main class="booklab-container">
  <section class="booklab-card">
    <h1>Электронная библиотека</h1>
    <p>Главная страница лабораторной работы №5. Загрузка текстовых книг, добавление обложек и просмотр жанров реализованы компонентами Vue.js.</p>
    <?php if (!is_user_logged_in()) : ?>
      <p class="booklab-error">Для загрузки книг и просмотра детальной информации необходимо авторизоваться.</p>
      <p><a class="booklab-btn" href="<?php echo esc_url(wp_login_url(home_url('/'))); ?>">Войти в систему</a></p>
    <?php endif; ?>
  </section>

  <div id="booklab-main-app"
       data-rest-url="<?php echo esc_url_raw(rest_url('booklab/v1')); ?>"
       data-nonce="<?php echo esc_attr(wp_create_nonce('wp_rest')); ?>"
       data-logged="<?php echo is_user_logged_in() ? '1' : '0'; ?>">
    <book-upload></book-upload>
    <cover-upload></cover-upload>
    <genre-list></genre-list>
  </div>
</main>
<?php get_footer(); ?>
