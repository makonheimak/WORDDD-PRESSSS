<?php get_header(); $book_id = absint(get_query_var('booklab_book_id')); ?>
<main class="booklab-container">
  <div id="booklab-book-app"
       data-rest-url="<?php echo esc_url_raw(rest_url('booklab/v1')); ?>"
       data-nonce="<?php echo esc_attr(wp_create_nonce('wp_rest')); ?>"
       data-book-id="<?php echo esc_attr($book_id); ?>">
    <book-detail-page></book-detail-page>
  </div>
</main>
<?php get_footer(); ?>
