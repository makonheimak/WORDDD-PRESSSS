<?php get_header(); $genre_id = absint(get_query_var('booklab_genre_id')); ?>
<main class="booklab-container">
  <div id="booklab-genre-app"
       data-rest-url="<?php echo esc_url_raw(rest_url('booklab/v1')); ?>"
       data-genre-id="<?php echo esc_attr($genre_id); ?>">
    <genre-books-page></genre-books-page>
  </div>
</main>
<?php get_footer(); ?>
