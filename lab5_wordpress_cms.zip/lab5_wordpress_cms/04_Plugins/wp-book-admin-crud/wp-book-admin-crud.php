<?php
/*
Plugin Name: WP Book Admin CRUD
Description: CRUD-плагин для управления таблицами книг и жанров лабораторной работы №5.
Version: 1.0.0
Author: Student
*/
if (!defined('ABSPATH')) { exit; }

function booklab_crud_table($name) {
    global $wpdb;
    return $wpdb->prefix . 'booklab_' . $name;
}

add_action('admin_menu', function() {
    add_menu_page('BookLab CRUD', 'BookLab CRUD', 'manage_options', 'booklab-crud', 'booklab_crud_books_page', 'dashicons-book-alt', 26);
    add_submenu_page('booklab-crud', 'Книги', 'Книги', 'manage_options', 'booklab-crud', 'booklab_crud_books_page');
    add_submenu_page('booklab-crud', 'Жанры', 'Жанры', 'manage_options', 'booklab-crud-genres', 'booklab_crud_genres_page');
});

add_action('admin_post_booklab_save_book', 'booklab_crud_save_book');
add_action('admin_post_booklab_delete_book', 'booklab_crud_delete_book');
add_action('admin_post_booklab_save_genre', 'booklab_crud_save_genre');
add_action('admin_post_booklab_delete_genre', 'booklab_crud_delete_genre');

function booklab_crud_notice($text) {
    echo '<div class="notice notice-info"><p>' . esc_html($text) . '</p></div>';
}

function booklab_crud_books_page() {
    global $wpdb;
    if (!current_user_can('manage_options')) { return; }
    $books = $wpdb->get_results('SELECT b.*, g.name AS genre_name FROM ' . booklab_crud_table('books') . ' b LEFT JOIN ' . booklab_crud_table('genres') . ' g ON g.id=b.genre_id ORDER BY b.id DESC');
    $genres = $wpdb->get_results('SELECT * FROM ' . booklab_crud_table('genres') . ' ORDER BY name ASC');
    $edit = null;
    if (!empty($_GET['edit'])) {
        $edit = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . booklab_crud_table('books') . ' WHERE id=%d', absint($_GET['edit'])));
    }
    echo '<div class="wrap"><h1>BookLab CRUD: книги</h1>';
    echo '<h2>' . ($edit ? 'Редактировать книгу' : 'Добавить книгу') . '</h2>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('booklab_save_book');
    echo '<input type="hidden" name="action" value="booklab_save_book">';
    echo '<input type="hidden" name="id" value="' . esc_attr($edit->id ?? 0) . '">';
    echo '<table class="form-table"><tr><th>Название</th><td><input class="regular-text" name="title" value="' . esc_attr($edit->title ?? '') . '" required></td></tr>';
    echo '<tr><th>Автор</th><td><input class="regular-text" name="author" value="' . esc_attr($edit->author ?? '') . '"></td></tr>';
    echo '<tr><th>Жанр</th><td><select name="genre_id"><option value="">---</option>';
    foreach ($genres as $g) { echo '<option value="' . esc_attr($g->id) . '" ' . selected((int)($edit->genre_id ?? 0), (int)$g->id, false) . '>' . esc_html($g->name) . '</option>'; }
    echo '</select></td></tr>';
    echo '<tr><th>Описание</th><td><textarea name="description" class="large-text" rows="4">' . esc_textarea($edit->description ?? '') . '</textarea></td></tr>';
    echo '<tr><th>URL файла</th><td><input class="large-text" name="file_url" value="' . esc_attr($edit->file_url ?? '') . '"></td></tr>';
    echo '<tr><th>Путь файла</th><td><input class="large-text" name="file_path" value="' . esc_attr($edit->file_path ?? '') . '"></td></tr>';
    echo '<tr><th>Цена</th><td><input type="number" step="0.01" name="price" value="' . esc_attr($edit->price ?? '0') . '"></td></tr></table>';
    submit_button($edit ? 'Сохранить изменения' : 'Добавить книгу');
    echo '</form><hr><h2>Список книг</h2><table class="widefat striped"><thead><tr><th>ID</th><th>Название</th><th>Автор</th><th>Жанр</th><th>Цена</th><th>Действия</th></tr></thead><tbody>';
    foreach ($books as $b) {
        echo '<tr><td>' . esc_html($b->id) . '</td><td>' . esc_html($b->title) . '</td><td>' . esc_html($b->author) . '</td><td>' . esc_html($b->genre_name) . '</td><td>' . esc_html($b->price) . '</td><td>';
        echo '<a href="' . esc_url(admin_url('admin.php?page=booklab-crud&edit=' . $b->id)) . '">Изменить</a> | ';
        echo '<a onclick="return confirm(\'Удалить книгу?\')" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=booklab_delete_book&id=' . $b->id), 'booklab_delete_book')) . '">Удалить</a>';
        echo '</td></tr>';
    }
    echo '</tbody></table></div>';
}

function booklab_crud_save_book() {
    global $wpdb;
    check_admin_referer('booklab_save_book');
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    $id = absint($_POST['id'] ?? 0);
    $data = [
        'title' => sanitize_text_field($_POST['title'] ?? ''),
        'author' => sanitize_text_field($_POST['author'] ?? ''),
        'genre_id' => !empty($_POST['genre_id']) ? absint($_POST['genre_id']) : null,
        'description' => wp_kses_post($_POST['description'] ?? ''),
        'file_url' => esc_url_raw($_POST['file_url'] ?? ''),
        'file_path' => sanitize_text_field($_POST['file_path'] ?? ''),
        'file_name' => basename(sanitize_text_field($_POST['file_path'] ?? 'manual.txt')),
        'file_size' => 0,
        'mime_type' => 'text/plain',
        'price' => (float)($_POST['price'] ?? 0),
        'updated_at' => current_time('mysql'),
    ];
    if ($id) { $wpdb->update(booklab_crud_table('books'), $data, ['id' => $id]); }
    else { $wpdb->insert(booklab_crud_table('books'), $data); }
    wp_safe_redirect(admin_url('admin.php?page=booklab-crud'));
    exit;
}

function booklab_crud_delete_book() {
    global $wpdb;
    check_admin_referer('booklab_delete_book');
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    $wpdb->delete(booklab_crud_table('covers'), ['book_id' => absint($_GET['id'] ?? 0)]);
    $wpdb->delete(booklab_crud_table('books'), ['id' => absint($_GET['id'] ?? 0)]);
    wp_safe_redirect(admin_url('admin.php?page=booklab-crud'));
    exit;
}

function booklab_crud_genres_page() {
    global $wpdb;
    if (!current_user_can('manage_options')) { return; }
    $genres = $wpdb->get_results('SELECT * FROM ' . booklab_crud_table('genres') . ' ORDER BY id DESC');
    $edit = null;
    if (!empty($_GET['edit'])) { $edit = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . booklab_crud_table('genres') . ' WHERE id=%d', absint($_GET['edit']))); }
    echo '<div class="wrap"><h1>BookLab CRUD: жанры</h1><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('booklab_save_genre');
    echo '<input type="hidden" name="action" value="booklab_save_genre"><input type="hidden" name="id" value="' . esc_attr($edit->id ?? 0) . '">';
    echo '<table class="form-table"><tr><th>Название</th><td><input class="regular-text" name="name" value="' . esc_attr($edit->name ?? '') . '" required></td></tr>';
    echo '<tr><th>Slug</th><td><input class="regular-text" name="slug" value="' . esc_attr($edit->slug ?? '') . '"></td></tr>';
    echo '<tr><th>Обложка URL</th><td><input class="large-text" name="cover_url" value="' . esc_attr($edit->cover_url ?? '') . '"></td></tr>';
    echo '<tr><th>Описание</th><td><textarea name="description" class="large-text" rows="4">' . esc_textarea($edit->description ?? '') . '</textarea></td></tr></table>';
    submit_button($edit ? 'Сохранить жанр' : 'Добавить жанр');
    echo '</form><hr><table class="widefat striped"><thead><tr><th>ID</th><th>Название</th><th>Slug</th><th>Действия</th></tr></thead><tbody>';
    foreach ($genres as $g) {
        echo '<tr><td>' . esc_html($g->id) . '</td><td>' . esc_html($g->name) . '</td><td>' . esc_html($g->slug) . '</td><td>';
        echo '<a href="' . esc_url(admin_url('admin.php?page=booklab-crud-genres&edit=' . $g->id)) . '">Изменить</a> | ';
        echo '<a onclick="return confirm(\'Удалить жанр?\')" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=booklab_delete_genre&id=' . $g->id), 'booklab_delete_genre')) . '">Удалить</a>';
        echo '</td></tr>';
    }
    echo '</tbody></table></div>';
}

function booklab_crud_save_genre() {
    global $wpdb;
    check_admin_referer('booklab_save_genre');
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    $id = absint($_POST['id'] ?? 0);
    $name = sanitize_text_field($_POST['name'] ?? '');
    $data = [
        'name' => $name,
        'slug' => sanitize_title($_POST['slug'] ?: $name),
        'description' => wp_kses_post($_POST['description'] ?? ''),
        'cover_url' => esc_url_raw($_POST['cover_url'] ?? ''),
    ];
    if ($id) { $wpdb->update(booklab_crud_table('genres'), $data, ['id' => $id]); }
    else { $wpdb->insert(booklab_crud_table('genres'), $data); }
    wp_safe_redirect(admin_url('admin.php?page=booklab-crud-genres'));
    exit;
}

function booklab_crud_delete_genre() {
    global $wpdb;
    check_admin_referer('booklab_delete_genre');
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    $wpdb->update(booklab_crud_table('books'), ['genre_id' => null], ['genre_id' => absint($_GET['id'] ?? 0)]);
    $wpdb->delete(booklab_crud_table('genres'), ['id' => absint($_GET['id'] ?? 0)]);
    wp_safe_redirect(admin_url('admin.php?page=booklab-crud-genres'));
    exit;
}
