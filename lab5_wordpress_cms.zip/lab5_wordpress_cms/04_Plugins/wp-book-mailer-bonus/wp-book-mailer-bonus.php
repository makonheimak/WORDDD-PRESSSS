<?php
/*
Plugin Name: WP Book Mailer Bonus
Description: Дополнительная заготовка второго варианта усложненного задания: рассылка 5 последних книг зарегистрированным пользователям.
Version: 1.0.0
Author: Student
*/
if (!defined('ABSPATH')) { exit; }

function booklab_mailer_table($name) { global $wpdb; return $wpdb->prefix . 'booklab_' . $name; }

add_action('admin_menu', function() {
    add_submenu_page('booklab-crud', 'Рассылка книг', 'Рассылка книг', 'manage_options', 'booklab-mailer', 'booklab_mailer_page');
});
add_action('admin_post_booklab_send_books_mail', 'booklab_send_books_mail');

function booklab_mailer_page() {
    echo '<div class="wrap"><h1>Рассылка последних книг</h1><p>Этот плагин является дополнительной заготовкой для варианта 5.3.2.2.</p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('booklab_send_books_mail');
    echo '<input type="hidden" name="action" value="booklab_send_books_mail">';
    echo '<p><input class="regular-text" name="subject" value="Новые книги в библиотеке"></p>';
    submit_button('Отправить зарегистрированным пользователям');
    echo '</form></div>';
}

function booklab_send_books_mail() {
    global $wpdb;
    check_admin_referer('booklab_send_books_mail');
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    $books = $wpdb->get_results('SELECT id, title, author FROM ' . booklab_mailer_table('books') . ' ORDER BY created_at DESC LIMIT 5');
    $lines = ['Последние добавленные книги:'];
    foreach ($books as $book) {
        $lines[] = '- ' . $book->title . ' — ' . $book->author . ' ' . home_url('/book/' . $book->id . '/');
    }
    $message = implode("\n", $lines);
    $users = get_users(['fields' => ['user_email']]);
    foreach ($users as $user) {
        wp_mail($user->user_email, sanitize_text_field($_POST['subject'] ?? 'Новые книги'), $message);
    }
    wp_safe_redirect(admin_url('admin.php?page=booklab-mailer'));
    exit;
}
