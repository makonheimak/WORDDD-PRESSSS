<?php
/*
Plugin Name: WP Book WooCommerce Integration
Description: Дополнительное задание: интеграция книг лабораторной работы №5 с WooCommerce для покупки книг.
Version: 1.0.0
Author: Student
*/
if (!defined('ABSPATH')) { exit; }

function booklab_wc_table($name) {
    global $wpdb;
    return $wpdb->prefix . 'booklab_' . $name;
}

add_action('admin_menu', function() {
    add_submenu_page('booklab-crud', 'WooCommerce книги', 'WooCommerce книги', 'manage_options', 'booklab-wc', 'booklab_wc_admin_page');
});

add_action('admin_post_booklab_wc_create_product', 'booklab_wc_create_product');

function booklab_wc_admin_page() {
    global $wpdb;
    if (!current_user_can('manage_options')) { return; }
    echo '<div class="wrap"><h1>BookLab WooCommerce</h1>';
    if (!class_exists('WooCommerce') || !class_exists('WC_Product_Simple')) {
        echo '<div class="notice notice-error"><p>Для работы механизма покупки установите и активируйте WooCommerce.</p></div></div>';
        return;
    }
    $books = $wpdb->get_results('SELECT * FROM ' . booklab_wc_table('books') . ' ORDER BY id DESC');
    echo '<p>Нажмите кнопку, чтобы создать товар WooCommerce на основе книги.</p><table class="widefat striped"><thead><tr><th>ID</th><th>Книга</th><th>Цена</th><th>Товар</th><th>Действие</th></tr></thead><tbody>';
    foreach ($books as $b) {
        $product_link = $b->wc_product_id ? '<a href="' . esc_url(get_edit_post_link((int)$b->wc_product_id)) . '">#' . esc_html($b->wc_product_id) . '</a>' : 'Не создан';
        $url = wp_nonce_url(admin_url('admin-post.php?action=booklab_wc_create_product&book_id=' . $b->id), 'booklab_wc_create_product');
        echo '<tr><td>' . esc_html($b->id) . '</td><td>' . esc_html($b->title) . '</td><td>' . esc_html($b->price) . '</td><td>' . $product_link . '</td><td><a class="button" href="' . esc_url($url) . '">Создать/обновить товар</a></td></tr>';
    }
    echo '</tbody></table></div>';
}

function booklab_wc_create_product() {
    global $wpdb;
    check_admin_referer('booklab_wc_create_product');
    if (!current_user_can('manage_options')) { wp_die('Forbidden'); }
    if (!class_exists('WC_Product_Simple')) { wp_die('WooCommerce не активирован.'); }
    $book_id = absint($_GET['book_id'] ?? 0);
    $book = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . booklab_wc_table('books') . ' WHERE id=%d', $book_id));
    if (!$book) { wp_die('Книга не найдена.'); }

    $product = !empty($book->wc_product_id) ? wc_get_product((int)$book->wc_product_id) : null;
    if (!$product) {
        $product = new WC_Product_Simple();
    }
    $product->set_name($book->title);
    $product->set_description($book->description);
    $product->set_regular_price((string)max(0, (float)$book->price));
    $product->set_virtual(true);
    $product->set_downloadable(true);
    if (class_exists('WC_Product_Download')) {
        $download = new WC_Product_Download();
        $download->set_name($book->file_name ?: $book->title);
        $download->set_file($book->file_url);
        $product->set_downloads([$download]);
    }
    $product_id = $product->save();
    $wpdb->update(booklab_wc_table('books'), ['wc_product_id' => $product_id, 'updated_at' => current_time('mysql')], ['id' => $book_id]);
    wp_safe_redirect(admin_url('admin.php?page=booklab-wc'));
    exit;
}

add_shortcode('booklab_buy_button', function($atts) {
    global $wpdb;
    $atts = shortcode_atts(['id' => 0], $atts);
    $book_id = absint($atts['id']);
    if (!$book_id || !function_exists('wc_get_product')) { return ''; }
    $product_id = $wpdb->get_var($wpdb->prepare('SELECT wc_product_id FROM ' . booklab_wc_table('books') . ' WHERE id=%d', $book_id));
    if (!$product_id) { return '<p>Товар для покупки пока не создан.</p>'; }
    $product = wc_get_product((int)$product_id);
    if (!$product) { return ''; }
    return '<a class="button" href="' . esc_url($product->add_to_cart_url()) . '">Купить книгу</a>';
});
