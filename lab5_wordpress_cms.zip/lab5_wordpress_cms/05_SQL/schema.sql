-- SQL-схема для лабораторной работы №5.
-- В реальном WordPress префикс wp_ может отличаться. В коде используется $wpdb->prefix.

CREATE TABLE wp_booklab_genres (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(160) NOT NULL UNIQUE,
    description TEXT NULL,
    cover_url VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);

CREATE TABLE wp_booklab_books (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    genre_id BIGINT UNSIGNED NULL,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NULL,
    description TEXT NULL,
    file_url VARCHAR(500) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_size BIGINT UNSIGNED NOT NULL,
    mime_type VARCHAR(120) NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    wc_product_id BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL,
    PRIMARY KEY (id),
    INDEX idx_books_genre_id (genre_id),
    INDEX idx_books_created_at (created_at)
);

CREATE TABLE wp_booklab_covers (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    book_id BIGINT UNSIGNED NOT NULL,
    cover_url VARCHAR(500) NOT NULL,
    cover_path VARCHAR(500) NOT NULL,
    is_main TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_covers_book_id (book_id)
);
