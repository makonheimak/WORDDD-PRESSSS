# Лабораторная работа N5: WordPress CMS для электронной библиотеки

## Описание

Проект реализует локальную WordPress CMS для электронной библиотеки. В системе можно загружать текстовые книги, добавлять обложки, распределять книги по жанрам, просматривать книги через Vue.js-страницы и покупать книги через WooCommerce.

## Требования

Для запуска нужен установленный и запущенный Docker Desktop.

Проверка Docker:

```powershell
docker version
```

## Запуск

1. Распаковать проект.
2. Открыть PowerShell в корневой папке проекта.
3. Убедиться, что в папке есть файлы:

```text
docker-compose.yml
start-local-wordpress.ps1
```

4. Выполнить:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-local-wordpress.ps1
```

После запуска открыть:

```text
http://localhost:8091
```

Админка:

```text
http://localhost:8091/wp-admin
```

Данные для входа:

```text
login: admin
password: admin
```

Важно: эта копия проекта использует порт `8091`, чтобы не конфликтовать с другими локальными WordPress-проектами.

## Структура проекта

```text
03_WordPress_theme/wp-book-vue-theme
```

Основная тема WordPress. Содержит шаблоны страниц, REST API, Vue.js-скрипты и создание таблиц.

```text
04_Plugins/wp-book-admin-crud
```

CRUD-плагин для управления книгами и жанрами.

```text
04_Plugins/wp-book-woocommerce
```

Плагин интеграции с WooCommerce для покупки книг.

```text
04_Plugins/wp-book-mailer-bonus
```

Дополнительный плагин рассылки последних книг.

```text
05_SQL/schema.sql
```

SQL-схема для просмотра структуры БД в MySQL Workbench.

```text
06_Test_files/example_book.txt
06_Test_files/example_cover.png
```

Файлы для проверки загрузки книги и обложки.

## Проверка БД

Выполнить из корня проекта:

```powershell
docker compose exec -T db mysql --default-character-set=utf8mb4 -uwordpress -pwordpress wordpress -e "SHOW TABLES LIKE 'wp_booklab_%'; SELECT id,name,slug FROM wp_booklab_genres;"
```

Должны быть таблицы:

- `wp_booklab_books`;
- `wp_booklab_genres`;
- `wp_booklab_covers`.

Жанры добавляются автоматически при активации темы.

## Проверка главной страницы

Открыть:

```text
http://localhost:8091
```

На странице должны быть Vue.js-блоки:

- загрузка текстовой книги;
- загрузка обложек;
- список жанров с книгами.

Если пользователь не авторизован, загрузка книги будет запрещена. Это ожидаемое поведение.

## Проверка загрузки книги

1. Открыть `http://localhost:8091/wp-login.php`.
2. Войти под `admin/admin`.
3. Вернуться на главную страницу `http://localhost:8091`.
4. Загрузить файл:

```text
06_Test_files/example_book.txt
```

После загрузки появится форма:

- название;
- автор;
- жанр;
- цена;
- описание.

## Проверка загрузки обложки

После загрузки книги станет доступен блок загрузки обложки.

Файл для проверки:

```text
06_Test_files/example_cover.png
```

Ограничение размера книги и обложки до 5 МБ реализовано в:

```text
03_WordPress_theme/wp-book-vue-theme/includes/helpers.php
```

## Проверка страницы жанра

Открыть:

```text
http://localhost:8091/genre/1/
```

Должна открыться страница жанра со списком книг.

Код страницы жанра:

```text
03_WordPress_theme/wp-book-vue-theme/assets/js/genre-page.js
```

## Проверка страницы книги

Без авторизации открыть:

```text
http://localhost:8091/book/3/
```

Доступ должен быть запрещен.

После входа `admin/admin` открыть эту же страницу. Должны отображаться:

- название книги;
- автор;
- описание;
- цена;
- ссылка для скачивания;
- ссылка на покупку через WooCommerce.

Ограничение доступа реализовано в REST API через `is_user_logged_in`.

## Проверка CRUD-плагина

Открыть:

```text
http://localhost:8091/wp-admin
```

В меню выбрать:

```text
BookLab CRUD
```

Проверить:

- просмотр книг;
- добавление книги;
- редактирование книги;
- удаление книги;
- управление жанрами.

Файл плагина:

```text
04_Plugins/wp-book-admin-crud/wp-book-admin-crud.php
```

## Проверка WooCommerce

Открыть в админке раздел:

```text
Products
```

Также можно открыть страницу товара:

```text
http://localhost:8091/product/demonstraczionnaya-kniga/
```

Файл интеграции:

```text
04_Plugins/wp-book-woocommerce/wp-book-woocommerce.php
```

## Проверка REST API

Открывать нужно ссылки именно на порту `8091`:

```text
http://localhost:8091/wp-json/booklab/v1/genres
http://localhost:8091/wp-json/booklab/v1/genres?only_with_books=1
http://localhost:8091/wp-json/booklab/v1/genres/1/books
```

Если открывать эти ссылки на `8090`, может появиться ошибка:

```json
{"code":"rest_no_route","message":"No route was found matching the URL and request method.","data":{"status":404}}
```

Это означает, что на `8090` открыт другой локальный WordPress-проект или не активирована нужная тема.

## Соответствие заданию

| Требование | Реализация |
|---|---|
| Таблицы книг и жанров | `wp_booklab_books`, `wp_booklab_genres` |
| Хранение обложек | `wp_booklab_covers`, поле `cover_url` |
| Создание таблиц при активации темы | `booklab_create_tables()` |
| Удаление таблиц при деактивации темы | `booklab_drop_tables()` |
| Предварительное добавление жанров | `booklab_seed_genres()` |
| Главная страница | `index.php`, `main-app.js` |
| Страница жанра | `genre-page.php`, `genre-page.js` |
| Страница книги | `book-page.php`, `book-page.js` |
| Vue.js | `assets/js/*.js` |
| REST API | `includes/rest-api.php` |
| Загрузка книги | компонент `BookUpload` |
| Загрузка обложки | компонент `CoverUpload` |
| Ограничение 5 МБ | `BOOKLAB_MAX_FILE_SIZE` |
| Доступ после авторизации | `is_user_logged_in` |
| CRUD-плагин | `wp-book-admin-crud` |
| WooCommerce-покупка | `wp-book-woocommerce` |

## Остановка

Остановить контейнеры:

```powershell
docker compose down
```

Удалить контейнеры и локальные данные:

```powershell
docker compose down -v
```

Команда `down -v` удаляет базу данных и загруженные файлы.
