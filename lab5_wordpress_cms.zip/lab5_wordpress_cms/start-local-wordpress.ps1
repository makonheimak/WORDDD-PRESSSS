$ErrorActionPreference = "Continue"

docker compose up -d

Write-Host "Waiting for WordPress..."
for ($i = 1; $i -le 30; $i++) {
    docker compose run --rm wpcli wp db check *> $null
    if ($LASTEXITCODE -eq 0) {
        break
    }
    Start-Sleep -Seconds 3
}

$oldErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
docker compose run --rm wpcli wp core is-installed *> $null
$isInstalledExitCode = $LASTEXITCODE
$ErrorActionPreference = $oldErrorActionPreference

if ($isInstalledExitCode -ne 0) {
    docker compose run --rm wpcli wp core install --url=http://localhost:8091 --title="BookLab" --admin_user=admin --admin_password=admin --admin_email=admin@example.com --skip-email
    $isInstalledExitCode = $LASTEXITCODE
    if ($isInstalledExitCode -ne 0) {
        Write-Host "WordPress installation failed. Check Docker logs."
        exit $isInstalledExitCode
    }
}

docker compose run --rm wpcli wp theme is-active wp-book-vue-theme *> $null
if ($LASTEXITCODE -ne 0) {
    docker compose run --rm wpcli wp theme activate wp-book-vue-theme
}

docker compose run --rm wpcli wp plugin is-installed woocommerce *> $null
if ($LASTEXITCODE -ne 0) {
    docker compose run --rm wpcli wp plugin install woocommerce --version=8.9.3 --activate
}
docker compose run --rm wpcli wp plugin is-active woocommerce *> $null
if ($LASTEXITCODE -ne 0) {
    docker compose run --rm wpcli wp plugin activate woocommerce
}

foreach ($plugin in @("wp-book-admin-crud", "wp-book-mailer-bonus", "wp-book-woocommerce")) {
    docker compose run --rm wpcli wp plugin is-active $plugin *> $null
    if ($LASTEXITCODE -ne 0) {
        docker compose run --rm wpcli wp plugin activate $plugin
    }
}
docker compose run --rm wpcli wp rewrite structure '/%postname%/' --hard

Write-Host ""
Write-Host "WordPress: http://localhost:8091"
Write-Host "Admin:     http://localhost:8091/wp-admin"
Write-Host "Login:     admin"
Write-Host "Password:  admin"
