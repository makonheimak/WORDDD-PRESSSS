<?php
global $wpdb;

$book_id = $wpdb->get_var($wpdb->prepare(
    "SELECT id FROM {$wpdb->prefix}booklab_books WHERE title = %s",
    'Демонстрационная книга'
));

if (!$book_id) {
    $wpdb->insert($wpdb->prefix . 'booklab_books', [
        'genre_id' => 1,
        'title' => 'Демонстрационная книга',
        'author' => 'Екатерина Умецкая',
        'description' => 'Тестовая электронная книга для демонстрации загрузки, просмотра по жанрам, скачивания и покупки через WooCommerce.',
        'file_url' => home_url('/wp-content/uploads/booklab/books/example_book.txt'),
        'file_path' => ABSPATH . 'wp-content/uploads/booklab/books/example_book.txt',
        'file_name' => 'example_book.txt',
        'file_size' => 1024,
        'mime_type' => 'text/plain',
        'price' => 250.00,
        'created_at' => current_time('mysql'),
    ]);
    $book_id = (int)$wpdb->insert_id;
}

$cover_exists = $wpdb->get_var($wpdb->prepare(
    "SELECT id FROM {$wpdb->prefix}booklab_covers WHERE book_id = %d",
    $book_id
));

if (!$cover_exists) {
    $wpdb->insert($wpdb->prefix . 'booklab_covers', [
        'book_id' => $book_id,
        'cover_url' => home_url('/wp-content/uploads/booklab/covers/example_cover.png'),
        'cover_path' => ABSPATH . 'wp-content/uploads/booklab/covers/example_cover.png',
        'is_main' => 1,
        'created_at' => current_time('mysql'),
    ]);
}

if (class_exists('WC_Product_Simple')) {
    $product_id = $wpdb->get_var($wpdb->prepare(
        "SELECT wc_product_id FROM {$wpdb->prefix}booklab_books WHERE id = %d",
        $book_id
    ));
    $product = $product_id ? wc_get_product((int)$product_id) : null;
    if (!$product) {
        $product = new WC_Product_Simple();
    }
    $product->set_name('Демонстрационная книга');
    $product->set_description('Покупка электронной книги через WooCommerce.');
    $product->set_regular_price('250.00');
    $product->set_virtual(true);
    $product->set_downloadable(true);
    $product_id = $product->save();
    $wpdb->update($wpdb->prefix . 'booklab_books', ['wc_product_id' => $product_id], ['id' => $book_id]);
}

echo "book_id={$book_id}\n";
